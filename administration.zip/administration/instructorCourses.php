<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../node_modules/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../node_modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="../css/animate.css-main/source/animate.css">
    <!-- my css-->
    <link rel="stylesheet" href="./styleadministration.css">
    <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <title>Administration</title>
    <?php 
        session_start();
        $host="localhost";
        $user="root";
        $password="";
        $db="my_database";
        try{
            // connexion à la base de données my_database
            $db = new PDO('mysql:host=localhost;dbname=my_database;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }
        catch(Exception $e){
            // En cas d'erreur, on affiche un message et on quitte la page
            die('Erreur : '.$e->getMessage());
        }
        if (isset($_GET['remove'])){
            $remove =(int)$_GET['remove'];
            $req=$db->prepare("UPDATE instructorcourse SET accept=1 WHERE id=?");
            $req->execute(array($remove));
        }
        if (isset($_GET['accept'])){
            $accept =(int)$_GET['accept'];
            $req1=$db->prepare("UPDATE instructorcourse SET accept=2 WHERE id=?");
            $req1->execute(array($accept));
        }
        $instructorCourses=$db->query('SELECT * FROM instructorCourse ORDER BY id DESC');
    ?>
</head>
<body>
    <div class="jumbotron">
        <div style="margin-left:30px;margin-top:-30px;">
            <center><h1><i>Administration<i></h1></center>
            </div>
            <div style="margin-left:30px;margin-top:-40px;">
            <a href="../index.html"  style="color:black;">
                <i class="fa fa-arrow-circle-left fa-2x"></i>&nbsp;&nbsp;&nbsp;<strong>Back Home</strong>
            </a>
        </div>
    </div>
    <div class="container">
            <ol class="col-12 breadcrumb">
                <li class="breadcrumb-item  active"><a href="./admin.php">Members Management</a></li>
                <li class="breadcrumb-item  active"><a href="./messages.php">Messages Management</a></li>
                <li class="breadcrumb-item active"><a href="./comments.php">Comments Management</a></li>
                <li class="breadcrumb-item active"><a href="./instructor.php">Instructors Management</a></li>
                <li class="breadcrumb-item"><a href="./instructorCourses.php" style="color:black;">Instructor's Courses Management</a></li>
            </ol>
    </div>
    <div class="container" style="overflow-Y:auto;">
        <table >
            <tr>
                <th>
                    Id
                </th>
                <th>
                    Id of the instructor
                </th>
                <th>
                    Field
                </th>
                <th>
                    The name of the course
                </th>
                <th>
                    The introduction
                </th>
                <th>
                    PDF
                </th>
                <th>
                    Video
                </th>
                <th>
                    EXAM
                </th>
                <th>
                    Upload the course
                </th>
                <th>
                    Remove
                </th>
            </tr>
            <?php while($course=$instructorCourses->fetch()){ ?>
                <tr>
                    <td><?php echo $course['id'];?></td>
                    <td><?php echo $course['instructorId'];?></td>
                    <td><?php echo $course['courseField'];?></td>
                    <td><?php echo $course['courseName'];?></td>
                    <td><div style="word-wrap: break-word;  width:20rem;"><?php echo $course['Introduction'];?></div></td>
                    <td><a href="../instructor/courses/pdf/<?= $course['pdf']?>" target="_blank">Upload the PDF</a></td>
                    <td><iframe style="width:20rem; height=300rem;" src="../instructor/courses/video/<?= $course['video'] ?>"></iframe></td>
                    <?php if($course['exam']!=NULL){ ?>
                    <td><a href="../instructor/courses/exam/<?= $course['exam']?>" target="_blank">Upload the EXAM</a></td>
                    <?php } else{ ?>
                    <td></td>
                    <?php } ?>
                    <td>
                        <?php if(($course['accept']==0)||($course['accept']==1)) {?>
                        <a href="instructorCourses.php?accept=<?= $course['id']?>">Accept</a>
                        <?php } elseif($course['accept']==2) { echo '<p style="color:green;">Accepted</p>';} ?>
                    </td>
                    <td>
                        <?php if(($course['accept']==0)||($course['accept']==2)) {?>
                        <a href="instructorCourses.php?remove=<?= $course['id']?>">Remove</a>
                        <?php } elseif($course['accept']==1) { echo '<p style="color:red;">Rejected</p>';} ?>
                    </td>
                </tr>
            <?php }?> 
        
        </table>
    </div>
</body>
</html>