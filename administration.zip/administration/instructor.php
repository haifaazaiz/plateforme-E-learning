<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../node_modules/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../node_modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="../css/animate.css-main/source/animate.css">
    <!-- my css-->
    <link rel="stylesheet" href="./styleadministration.css">
    <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <title>Administration</title>
    <?php 
        session_start();
        $host="localhost";
        $user="root";
        $password="";
        $db="my_database";
        try{
            // connexion à la base de données my_database
            $db = new PDO('mysql:host=localhost;dbname=my_database;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }
        catch(Exception $e){
            // En cas d'erreur, on affiche un message et on quitte la page
            die('Erreur : '.$e->getMessage());
        }
        $instructors=$db->query('SELECT * FROM instructor ORDER BY idInstructor DESC');
    ?>
</head>
<body>
    <div class="jumbotron">
        <div style="margin-left:30px;margin-top:-30px;">
            <center><h1><i>Administration<i></h1></center>
            </div>
            <div style="margin-left:30px;margin-top:-40px;">
            <a href="../index.html"  style="color:black;">
                <i class="fa fa-arrow-circle-left fa-2x"></i>&nbsp;&nbsp;&nbsp;<strong>Back Home</strong>
            </a>
        </div>
    </div>
    <div class="container">
            <ol class="col-12 breadcrumb">
                <li class="breadcrumb-item  active"><a href="./admin.php">Members Management</a></li>
                <li class="breadcrumb-item  active"><a href="./messages.php">Messages Management</a></li>
                <li class="breadcrumb-item active"><a href="./comments.php">Comments Management</a></li>
                <li class="breadcrumb-item"><a href="./instructor.php"  style="color:black;">Instructors Management</a></li>
                <li class="breadcrumb-item active"><a href="./instructorCourses.php">Instructor's Courses Management</a></li>
            </ol>
    </div>
    <div class="container" style="overflow-Y:auto;">
        <table>
            <tr>
                <th>
                    Id
                </th>
                <th>
                    Email
                </th>
                <th>
                    First time instructor ?
                </th>
                <th>
                    Professionnal Experience
                </th>
                <th>
                    Motivation Letter
                </th>
                <th>
                    CV
                </th>
                <th>
                    Video
                </th>
                <th>
                    Accept the request
                </th>
                <th>
                    Reject the request
                </th>
            </tr>
            <?php while($instructor=$instructors->fetch()){ 
                    $req=$db->prepare("SELECT * FROM members WHERE email=?");
                    $req->execute(array($instructor['instructorMail']));
                    $user=$req->fetch(); ?>
                    <tr>
                        <td><?php echo $instructor['idInstructor'];?></td>
                        <td><?php echo $instructor['instructorMail'];?></td>
                        <td><?php echo $instructor['QyesornoInstructor'];?></td>
                        <td><?php echo $instructor['QexperienceInstructor'];?></td>
                        <td><div style="word-wrap: break-word;  width:20rem;"><?php echo $instructor['Motivationletter'];?></div></td>
                        <td><a href="../instructor/cv/<?= $instructor['instructorCv']?>" target="_blank">Upload the CV</a></td>
                        <td><iframe style="width:20rem; height=300rem;" src="../instructor/video/<?= $instructor['instructorVideo'] ?>"></iframe></td>
                        <td>
                            <?php 
                                if ($user['accessRights']=="0"){ ?>
                                <a href="send1.php?email=<?= $user['email']?>">Accept</a>
                            <?php } else { echo "<strong><p style='color:green;'>Accepted</p></strong>" ;} ?>
                        </td>
                        <td>
                            <?php 
                                if ($user['accessRights']=="0"){ ?>
                                <a href="send2.php?email=<?= $user['email']?>">Reject</a>
                            <?php } elseif ($user['accessRights']=="1"){ ?>
                                <a href="send2.php?email=<?= $user['email']?>">Remove this member from the instructors</a>
                            <?php } ?> 
                        </td>
                    </tr>
            <?php }?> 
        </table>
    </div>
</body>
</html>
