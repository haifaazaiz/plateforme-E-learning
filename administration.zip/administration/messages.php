<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../node_modules/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../node_modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="../css/animate.css-main/source/animate.css">
    <!-- my css-->
    <link rel="stylesheet" href="./styleadministration.css">
    <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <title>Administration</title>
    <?php 
        session_start();
        $host="localhost";
        $user="root";
        $password="";
        $db="my_database";
        try{
            // connexion à la base de données my_database
            $db = new PDO('mysql:host=localhost;dbname=my_database;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }
        catch(Exception $e){
            // En cas d'erreur, on affiche un message et on quitte la page
            die('Erreur : '.$e->getMessage());
        }
        if ((isset($_GET['remove']))&&(!empty($_GET['remove']))){
            $remove =(int)$_GET['remove'];
            $req=$db->prepare("DELETE FROM messages WHERE id=?");
            $req->execute(array($remove));
        }
        $messages=$db->query('SELECT * FROM messages ORDER BY id DESC');
    ?>
</head>
<body>
    <div class="jumbotron">
        <div style="margin-left:30px;margin-top:-30px;">
            <center><h1><i>Administration<i></h1></center>
            </div>
            <div style="margin-left:30px;margin-top:-40px;">
            <a href="../index.html"  style="color:black;">
                <i class="fa fa-arrow-circle-left fa-2x"></i>&nbsp;&nbsp;&nbsp;<strong>Back Home</strong>
            </a>
        </div>
    </div>
    <div class="container">
            <ol class="col-12 breadcrumb">
                <li class="breadcrumb-item active"><a href="./admin.php">Members Management</a></li>
                <li class="breadcrumb-item"><a href="./messages.php"  style="color:black;">Messages Management</a></li>
                <li class="breadcrumb-item active"><a href="./comments.php">Comments Management</a></li>
                <li class="breadcrumb-item active"><a href="./instructor.php">Instructors Management</a></li>
                <li class="breadcrumb-item active"><a href="./instructorCourses.php">Instructor's Courses Management</a></li>
            </ol>
    </div>
    <div class="container">
        <table>
            <tr>
                <th>
                    Id
                </th>
                <th>
                    First Name
                </th>
                <th>
                    Last Name
                </th>
                <th>
                    Email
                </th>
                <th>
                    Message
                </th>
                <th>
                    Reply
                </th>
                <th>
                    Remove
                </th>
            </tr>
            <?php while($msg=$messages->fetch()){ ?>
                    <tr>
                        <td><?php echo $msg['id']; $_SESSION['id']=$msg['id'];?></td>
                        <td><?php echo $msg['first_name']?></td>
                        <td><?php echo $msg['last_name']?></td>
                        <td><?php echo $msg['email']; $_SESSION['email']=$msg['email'];?></td>
                        <td style="word-wrap: break-word;  width:20rem;"><?php echo $msg['message']; $_SESSION['message']=$msg['message'];?></td>
                        <td>
                            <?php if($msg['reply']==0) {?>
                            <a href="send.php?id=<?= $msg['id']?>">Reply</a>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if($msg['remove']==0) {?>
                            <a href="messages.php?remove=<?= $msg['id']?>">Remove</a>
                            <?php } ?>
                        </td>
                    </tr>
            <?php }?> 
        </table>
    </div>
</body>
</html>
