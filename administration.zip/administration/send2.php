<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../node_modules/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../node_modules/bootstrap-social/bootstrap-social.css">
    <link rel="stylesheet" href="../css/animate.css-main/source/animate.css">
    <!-- my css-->
    <link rel="stylesheet" href="./styleadministration.css">
    <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <title>Administration</title>
    <?php 
        session_start();
        $host="localhost";
        $user="root";
        $password="";
        $db="my_database";
        try{
            // connexion à la base de données my_database
            $db = new PDO('mysql:host=localhost;dbname=my_database;charset=utf8','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }
        catch(Exception $e){
            // En cas d'erreur, on affiche un message et on quitte la page
            die('Erreur : '.$e->getMessage());
        }
        $sql=$db->prepare("SELECT * FROM members WHERE email=?");
        $sql->execute(array($_GET['email']));
        $user=$sql->fetch();
        if (isset($_POST['submit'])&&(!empty($_POST['text']))){
            if($user['accessRights']=="1"){
                $req1=$db->prepare("UPDATE members SET accessRights= :accessRights WHERE email= :email");
                $req1->execute(array(
                    'accessRights' => "0",
                    'email' => $_GET['email']
            ));
            }
            $header='From : haifaazaiz1@gmail.com';
            $object="The response of your request to be an instructor";
            $mail=$_GET['email'];
            $text=$_POST['text'];
            if(mail($mail,$object,$text,$header)){
                $msg="Email has been successfully sent !";
            }
            else{
                $msg="Failed to send email!";
            }    
            $req=$db->prepare("DELETE FROM instructor WHERE instructorMail=?");
            $req->execute(array($_GET['email']));
        }
        ?>
</head>
<body>
    <div class="jumbotron">
        <div style="margin-left:30px;margin-top:-30px;">
            <center><h1><i>Administration<i></h1></center>
            </div>
            <div style="margin-left:30px;margin-top:-40px;">
            <a href="../index.html"  style="color:black;">
                <i class="fa fa-arrow-circle-left fa-2x"></i>&nbsp;&nbsp;&nbsp;<strong>Back Home</strong>
            </a>
        </div>
    </div>
    <div class="container">
            <ol class="col-12 breadcrumb">
                <li class="breadcrumb-item  active"><a href="./instructor.php">Instructors Management</a></li>
                <li class="breadcrumb-item"><a href="./send.php"  style="color:black;">Send Email</a></li>
            </ol>
    </div>
    <div class="container">
        <CENTER>
            <form action="send2.php?email=<?= $user['email']?>" method="POST">
                <input type="textarea" id="text" name="text" placeholder="Enter your email text here" required>
                <br>
                <input type="submit" name="submit" id="submit" class="btn btn-primary btn-sm ml-1" value="Reject the request and Send the email">
                <br>
                <?php
                    if (isset($msg)) echo $msg;
                ?>
            </form>
        </CENTER>               
    </div>         
</body>
</html>
