document.getElementById('loginButton').addEventListener("click", function() {
	document.querySelector('.bg-modal').style.display = "flex";
});
document.querySelector('.close').addEventListener("click", function() {
	document.querySelector('.bg-modal').style.display = "none";
});
document.getElementById('signUpButton').addEventListener("click", function() {
	document.querySelector('.sg-modal').style.display = "flex";
});
document.querySelector('.sign').addEventListener("click", function() {
	document.querySelector('.sg-modal').style.display = "none";
});

function validation()
{
	adresse = document.formulaire.email.value;
	taille = adresse.length;
	
	validelog = false;
	validedom = false;
	valideext = false;

	arob = adresse.lastIndexOf("@");
	login = adresse.substring(0,arob);
	pointfinal = adresse.lastIndexOf(".");
	extension = adresse.substring(pointfinal,taille);
	domaine = adresse.substring(arob+1,pointfinal);

	if ( login.length > 2 )
	{
	validelog = true;
	}
	if ( domaine.length > 1 )
	{
	validedom = true;
	}
	if ( pointfinal > -1 && (extension.length == 3 || extension.length == 4) )
	{
	valideext = true;
	}
	if ( validelog == true && validedom == true && valideext == true )
	{
	return true;
	}
	else
	{
	alert('Ceci n\'est pas une adresse e-mail valide.');
	return false;
	}
};
